import sys, json

dir = "lb_config.json"
with open(dir) as file:
        confs = json.load(file)

for arg in sys.argv[1:]:
    if '--service_mac=' in arg:
        confs['service_mac'] = arg.replace('--service_mac=', '')
    
    elif '--service_ip_blue=' in arg:
        confs['service_ips']['blue'] = arg.replace('--service_ip_blue=', '')

    elif '--service_ip_red=' in arg:
        confs['service_ips']['red'] = arg.replace('--service_ip_red=', '')

    elif '--server_ip_blue=' in arg:
        confs['server_ips']['blue'] = arg.replace('--server_ip_blue=', '').split(',')

    elif '--server_ip_red=' in arg:
        confs['server_ips']['red'] = arg.replace('--server_ip_red=', '').split(',')
    
    elif '--proactive_mode=' in arg:
        pm = True
        if arg.replace('--proactive_mode=', '') == 'false':
            pm = False
        confs['proactive_mode'] = pm
    
    with open(dir, 'w') as outfile:
        json.dump(confs, outfile, indent=4)

